//
//  HeaderView.swift
//  07-TaskScrapping
//
//  Created by Carlos Daniel Pedrerol on 22/10/2020.
//  Copyright © 2020 Carlos Daniel Pedrerol. All rights reserved.
//

import UIKit

class HeaderView: UICollectionReusableView {
    
    
    @IBOutlet weak var labelHeader: UILabel!
    
}

class FooterView: UICollectionReusableView {
    
    @IBOutlet weak var buttomPage: UISegmentedControl!
    
    
    
   
    @IBAction func changePage(_ sender: Any) {
    
        /*
             if  buttomPage.selectedSegmentIndex == 0 {
                     
                 }else { buttomPage.selectedSegmentIndex == 1 {
                 
                 }*/
    
    }
    
    
        
}
