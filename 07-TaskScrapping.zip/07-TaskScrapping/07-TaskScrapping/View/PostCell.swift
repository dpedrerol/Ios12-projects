//
//  PostCell.swift
//  07-TaskScrapping
//
//  Created by Carlos Daniel Pedrerol on 16/10/2020.
//  Copyright © 2020 Carlos Daniel Pedrerol. All rights reserved.
//

import UIKit

class PostCell: UICollectionViewCell {
    
    @IBOutlet weak var imageViewPost: UIImageView!
        
    @IBOutlet weak var labelPost: UILabel!
    

    }


    
  

